"""
Cloud RL Decision Engine
=========================
Makes trading decisions based on the collective RL brain (7,559+ experiences).
This runs ONLY on the cloud - user bots never see this logic.
"""

import logging
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import math

logger = logging.getLogger(__name__)


class CloudRLDecisionEngine:
    """
    Cloud-side RL decision engine that analyzes market states and decides
    whether user bots should take trades.
    
    User bots send market conditions → This analyzes with RL brain → Returns decision
    """
    
    def __init__(self, experiences: List[Dict]):
        """
        Initialize with collective RL brain.
        
        Args:
            experiences: List of all trade experiences from Azure Blob Storage
        """
        self.experiences = experiences
        self.default_confidence_threshold = 0.5  # 50% default
        
        logger.info(f"🧠 Cloud RL Engine initialized with {len(experiences)} experiences")
    
    def should_take_signal(self, state: Dict) -> Tuple[bool, float, str]:
        """
        Decide if a user bot should take this trade based on market state.
        
        Args:
            state: Current market conditions {rsi, vwap_distance, atr, volume_ratio, 
                   hour, day_of_week, recent_pnl, streak, side, price}
        
        Returns:
            (take_trade, confidence, reason)
        """
        # Calculate confidence using dual pattern matching
        confidence, reason = self.calculate_confidence(state)
        
        # Decision: take if confidence > threshold
        take_trade = confidence >= self.default_confidence_threshold
        
        if take_trade:
            decision_reason = f"✅ TAKE ({confidence:.1%} confidence) - {reason}"
        else:
            decision_reason = f"❌ SKIP ({confidence:.1%} confidence) - {reason}"
        
        return take_trade, confidence, decision_reason
    
    def calculate_confidence(self, current_state: Dict) -> Tuple[float, str]:
        """
        Calculate confidence score using dual pattern matching:
        - Find similar WINNING experiences → boost confidence
        - Find similar LOSING experiences → reduce confidence
        
        Returns:
            (confidence, reason)
        """
        # Need minimum experiences
        if len(self.experiences) < 10:
            return 0.65, f"🆕 Limited experience ({len(self.experiences)} trades) - optimistic"
        
        # Separate winners and losers
        winners = [exp for exp in self.experiences if exp.get('reward', 0) > 0]
        losers = [exp for exp in self.experiences if exp.get('reward', 0) <= 0]
        
        if len(winners) < 5:
            return 0.65, f"🆕 Limited winning experience ({len(winners)} wins) - optimistic"
        
        # Find similar patterns
        similar_winners = self.find_similar_states(current_state, max_results=10, experiences=winners)
        similar_losers = self.find_similar_states(current_state, max_results=10, experiences=losers) if len(losers) >= 5 else []
        
        # Calculate winner confidence
        if similar_winners:
            winner_wins = sum(1 for exp in similar_winners if exp['reward'] > 0)
            winner_win_rate = winner_wins / len(similar_winners)
            winner_avg_profit = sum(exp['reward'] for exp in similar_winners) / len(similar_winners)
            
            winner_confidence = (winner_win_rate * 0.9) + (min(winner_avg_profit / 300, 1.0) * 0.1)
            winner_confidence = max(0.0, min(1.0, winner_confidence))
        else:
            winner_confidence = 0.5
            winner_win_rate = 0.5
            winner_avg_profit = 0
        
        # Calculate loser penalty
        if similar_losers:
            loser_losses = sum(1 for exp in similar_losers if exp['reward'] < 0)
            loser_loss_rate = loser_losses / len(similar_losers)
            loser_avg_loss = sum(exp['reward'] for exp in similar_losers) / len(similar_losers)
            
            loser_penalty = (loser_loss_rate * 0.4) + (min(abs(loser_avg_loss) / 300, 1.0) * 0.1)
            loser_penalty = max(0.0, min(0.5, loser_penalty))
        else:
            loser_penalty = 0.0
            loser_loss_rate = 0.0
            loser_avg_loss = 0
        
        # Dual pattern matching: Winners - Losers
        final_confidence = winner_confidence - loser_penalty
        final_confidence = max(0.0, min(1.0, final_confidence))
        
        # Build reason
        reason = f"{len(similar_winners)}W/{len(similar_losers)}L similar"
        reason += f" | Winners: {winner_win_rate*100:.0f}% WR, ${winner_avg_profit:.0f} avg"
        
        if similar_losers:
            reason += f" | Losers: {loser_loss_rate*100:.0f}% LR, ${loser_avg_loss:.0f} avg"
            reason += f" | Penalty: -{loser_penalty:.1%}"
        
        if final_confidence < 0.3:
            reason += " | LOOKS LIKE PAST LOSERS"
        
        return final_confidence, reason
    
    def find_similar_states(self, current_state: Dict, max_results: int = 10, 
                           experiences: Optional[List[Dict]] = None) -> List[Dict]:
        """
        Find past experiences with similar market conditions.
        
        Uses Euclidean distance to measure similarity across multiple dimensions:
        - RSI deviation
        - VWAP distance
        - ATR (volatility)
        - Volume ratio
        - Time of day
        - Day of week
        - Recent P&L
        - Win/loss streak
        
        Args:
            current_state: Current market state
            max_results: Max number of similar experiences to return
            experiences: Optional subset of experiences to search (for winner/loser filtering)
        
        Returns:
            List of similar experiences, sorted by similarity (most similar first)
        """
        exp_list = experiences if experiences is not None else self.experiences
        
        if not exp_list:
            return []
        
        # Extract current state features
        current_rsi = current_state.get('rsi', 50)
        current_vwap_dist = current_state.get('vwap_distance', 0)
        current_atr = current_state.get('atr', 0)
        current_vol_ratio = current_state.get('volume_ratio', 1.0)
        current_hour = current_state.get('hour', 12)
        current_dow = current_state.get('day_of_week', 0)
        current_pnl = current_state.get('recent_pnl', 0)
        current_streak = current_state.get('streak', 0)
        
        # Calculate distance to each experience
        distances = []
        
        for exp in exp_list:
            exp_state = exp.get('state', {})
            
            # Calculate weighted Euclidean distance
            rsi_diff = abs(current_rsi - exp_state.get('rsi', 50))
            vwap_diff = abs(current_vwap_dist - exp_state.get('vwap_distance', 0)) * 100
            atr_diff = abs(current_atr - exp_state.get('atr', 0))
            vol_diff = abs(current_vol_ratio - exp_state.get('volume_ratio', 1.0)) * 10
            hour_diff = abs(current_hour - exp_state.get('hour', 12))
            dow_diff = abs(current_dow - exp_state.get('day_of_week', 0))
            pnl_diff = abs(current_pnl - exp_state.get('recent_pnl', 0)) / 100
            streak_diff = abs(current_streak - exp_state.get('streak', 0))
            
            # Euclidean distance
            distance = math.sqrt(
                (rsi_diff ** 2) +
                (vwap_diff ** 2) +
                (atr_diff ** 2) +
                (vol_diff ** 2) +
                (hour_diff ** 2) +
                (dow_diff ** 2) +
                (pnl_diff ** 2) +
                (streak_diff ** 2)
            )
            
            distances.append((distance, exp))
        
        # Sort by distance (most similar first)
        distances.sort(key=lambda x: x[0])
        
        # Return top N most similar
        return [exp for _, exp in distances[:max_results]]
    
    def record_outcome(self, state: Dict, took_trade: bool, pnl: float, duration: float) -> Dict:
        """
        Record a trade outcome to the RL brain.
        This gets called after user bot executes and reports results.
        
        Args:
            state: Market state when signal occurred
            took_trade: Whether trade was taken
            pnl: Profit/loss in dollars
            duration: Trade duration in seconds
        
        Returns:
            Experience dictionary to be saved to Azure Blob
        """
        experience = {
            'timestamp': datetime.now().isoformat(),
            'state': state,
            'action': {
                'took_trade': took_trade,
                'exploration_rate': 0.0  # Cloud never explores (always exploitation)
            },
            'reward': pnl,
            'duration': duration
        }
        
        return experience
    
    def get_stats(self) -> Dict:
        """
        Get statistics about the RL brain.
        
        Returns:
            Dictionary with win rate, avg reward, total experiences, etc.
        """
        if not self.experiences:
            return {
                'total_experiences': 0,
                'win_rate': 0.0,
                'avg_reward': 0.0,
                'total_reward': 0.0
            }
        
        trades_taken = [exp for exp in self.experiences if exp.get('action', {}).get('took_trade', False)]
        
        if not trades_taken:
            return {
                'total_experiences': len(self.experiences),
                'win_rate': 0.0,
                'avg_reward': 0.0,
                'total_reward': 0.0
            }
        
        winners = sum(1 for exp in trades_taken if exp.get('reward', 0) > 0)
        total_reward = sum(exp.get('reward', 0) for exp in trades_taken)
        
        return {
            'total_experiences': len(self.experiences),
            'trades_taken': len(trades_taken),
            'win_rate': winners / len(trades_taken) if trades_taken else 0.0,
            'avg_reward': total_reward / len(trades_taken) if trades_taken else 0.0,
            'total_reward': total_reward
        }
