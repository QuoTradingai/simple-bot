"""
QuoTrading Flask API with RL Brain + PostgreSQL License Validation
Simple, reliable API that works everywhere
"""
from flask import Flask, request, jsonify
from azure.storage.blob import BlobServiceClient
import os
import json
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime
import logging
import statistics

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

# Azure Storage configuration (for RL data)
STORAGE_CONNECTION_STRING = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = "rl-data"
BLOB_NAME = "signal_experience.json"

# PostgreSQL configuration
DB_HOST = os.environ.get("DB_HOST", "quotrading-db.postgres.database.azure.com")
DB_NAME = os.environ.get("DB_NAME", "quotrading")
DB_USER = os.environ.get("DB_USER", "quotradingadmin")
DB_PASSWORD = os.environ.get("DB_PASSWORD")

# Global cache
_experiences_cache = None

def get_db_connection():
    """Get PostgreSQL database connection"""
    try:
        # Try standard username first, then flexible server format if needed
        try:
            conn = psycopg2.connect(
                host=DB_HOST,
                database=DB_NAME,
                user=DB_USER,
                password=DB_PASSWORD,
                sslmode='require',
                connect_timeout=10
            )
            return conn
        except psycopg2.OperationalError:
            # Fallback for flexible server if simple username fails
            user_with_server = f"{DB_USER}@{DB_HOST.split('.')[0]}" if '@' not in DB_USER else DB_USER
            conn = psycopg2.connect(
                host=DB_HOST,
                database=DB_NAME,
                user=user_with_server,
                password=DB_PASSWORD,
                sslmode='require',
                connect_timeout=10
            )
            return conn
            
    except Exception as e:
        logging.error(f"❌ Database connection failed: {e}")
        logging.error(f"   Host: {DB_HOST}, User: {DB_USER}, DB: {DB_NAME}")
        return None

def validate_license(license_key: str):
    """Validate license key against PostgreSQL database"""
    if not license_key:
        return False, "License key required"
    
    conn = get_db_connection()
    if not conn:
        return False, "Database connection failed"
    
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute("""
                SELECT license_key, email, license_type, license_status, 
                       license_expiration, created_at
                FROM users 
                WHERE license_key = %s
            """, (license_key,))
            
            user = cursor.fetchone()
            
            if not user:
                return False, "Invalid license key"
            
            # Check if license is active (case-insensitive)
            if user['license_status'].lower() != 'active':
                return False, f"License is {user['license_status']}"
            
            # Check expiration
            if user['license_expiration']:
                if datetime.now() > user['license_expiration']:
                    return False, "License expired"
            
            # Log successful validation
            cursor.execute("""
                INSERT INTO api_logs (license_key, endpoint, request_data, status_code)
                VALUES (%s, %s, %s, %s)
            """, (license_key, '/api/main', '{"action": "validate"}', 200))
            conn.commit()
            
            return True, f"Valid {user['license_type']} license"
            
    except Exception as e:
        logging.error(f"License validation error: {e}")
        return False, str(e)
    finally:
        conn.close()

def load_experiences():
    """Load RL experiences from Azure Storage"""
    global _experiences_cache
    
    if _experiences_cache is not None:
        return _experiences_cache
    
    if not STORAGE_CONNECTION_STRING:
        logging.warning("No Azure Storage connection string - using empty experiences")
        _experiences_cache = []
        return _experiences_cache
    
    try:
        blob_service = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
        container_client = blob_service.get_container_client(CONTAINER_NAME)
        blob_client = container_client.get_blob_client(BLOB_NAME)
        
        blob_data = blob_client.download_blob().readall()
        experiences_data = json.loads(blob_data)
        
        _experiences_cache = experiences_data.get("experiences", [])
        logging.info(f"✅ Loaded {len(_experiences_cache)} experiences from Azure Storage")
        
        return _experiences_cache
        
    except Exception as e:
        logging.error(f"❌ Failed to load experiences: {e}")
        _experiences_cache = []
        return _experiences_cache

def calculate_confidence(signal_type: str, regime: str, vix_level: float, experiences: list) -> float:
    """Calculate signal confidence based on RL experiences"""
    if not experiences:
        return 0.5
    
    # Filter similar experiences
    similar = [
        exp for exp in experiences
        if exp.get('signal_type') == signal_type and exp.get('regime') == regime
    ]
    
    if not similar:
        return 0.5
    
    # Calculate average reward from similar experiences
    rewards = [exp.get('reward', 0) for exp in similar]
    avg_reward = statistics.mean(rewards) if rewards else 0
    
    # Convert reward to confidence (0.0 to 1.0)
    confidence = max(0.0, min(1.0, (avg_reward + 1.0) / 2.0))
    
    return round(confidence, 3)

@app.route('/api/hello', methods=['GET'])
def hello():
    """Health check endpoint"""
    experiences = load_experiences()
    return jsonify({
        "status": "success",
        "message": f"✅ QuoTrading Flask API is running!",
        "experiences_loaded": len(experiences),
        "database_configured": bool(DB_PASSWORD)
    }), 200

@app.route('/api/main', methods=['POST'])
def main():
    """Main signal processing endpoint with license validation"""
    try:
        data = request.get_json()
        
        # Validate license
        license_key = data.get('license_key')
        is_valid, message = validate_license(license_key)
        
        if not is_valid:
            return jsonify({
                "status": "error",
                "message": message,
                "license_valid": False
            }), 403
        
        # Process signal with RL brain
        signal_type = data.get('signal_type', 'NEUTRAL')
        regime = data.get('regime', 'RANGING')
        vix_level = data.get('vix_level', 15.0)
        
        experiences = load_experiences()
        confidence = calculate_confidence(signal_type, regime, vix_level, experiences)
        
        response = {
            "status": "success",
            "license_valid": True,
            "message": message,
            "signal_confidence": confidence,
            "experiences_used": len(experiences),
            "signal_type": signal_type,
            "regime": regime
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logging.error(f"Error processing request: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/', methods=['GET'])
def root():
    """Root endpoint"""
    return jsonify({
        "status": "success",
        "message": "QuoTrading API",
        "endpoints": ["/api/hello", "/api/main"]
    }), 200

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
